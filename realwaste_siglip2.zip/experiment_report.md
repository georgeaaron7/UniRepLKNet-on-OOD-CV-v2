# Frozen SigLIP 2 for authentic landfill material classification

Experiment started: 2026-11-09T11:57:06.044883+00:00. Report generated: 2026-11-09T12:00:04.967652+00:00.

## Abstract
We evaluate an existing SigLIP 2 ViT-B/16 image encoder on the existing RealWaste
dataset using a frozen encoder and a class-balanced linear classifier. An ImageNet
ResNet-18 and a majority-class rule provide baselines. Under three fixed stratified
image-level splits, SigLIP 2 obtains mean test macro-F1
92.47% (sample SD
0.58 percentage points).
Its mean macro-F1 is 10.79 percentage points higher than ResNet-18.
This is an empirical model–dataset application study; no new model architecture is proposed.

## Motivation and contribution
Authentic discarded materials differ from clean product photographs. We ask whether
the transferable representations of a pretrained SigLIP 2 image tower are useful for
the nine-class material task without updating the backbone. The contribution is a
reproducible evaluation of this specific model–dataset pairing, including a baseline,
label-efficiency conditions, per-class analysis, and measured compute costs.
A targeted search on 9 November 2026 found no direct SigLIP 2–RealWaste evaluation.
Search coverage is incomplete: this is not a guaranteed first-ever combination.
Foundation-model waste classification, including DINOv3 on RealWaste, is prior work.

## Data and reproducibility
Source: UCI RealWaste (DOI 10.24432/C5SS4G), 4752 original images;
4752 after removing 0 exact
decoded-pixel duplicates. Dataset manifest SHA-256: `cafdf72bbfbdea5cd2815320fd4eaf7ed950ec5c73611cbce6fe656dd17f37ca`.
Class labels: Cardboard, Food Organics, Glass, Metal, Miscellaneous Trash, Paper, Plastic, Textile Trash, Vegetation.
Images, duplicate groups, split membership and label subsets are recorded in CSV/JSON.
Raw data are not included in this output archive; use the cited source.

## Methods
Frozen encoders: `timm/resnet18.a1_in1k` and
`timm/vit_base_patch16_siglip_224.v2_webli`, pinned to commits in config.json.
Images use 224 × 224 inputs and checkpoint-specific deterministic transforms.
ResNet's default evaluation resolution is explicitly overridden to 224.
Every embedding is L2-normalized independently. No encoder weights are trained.
For each seed [42, 123, 2026], stratify 70/15/15 into train/validation/test;
select logistic regression C from [0.01, 0.1, 1.0, 10.0] using validation macro-F1 only,
with class_weight='balanced', solver='lbfgs', max_iter=2000.
Do not refit on validation or test data. Both encoders share all partitions and
training subsets. Conditions use 10%, 25%, or 100% of training labels, while the
full validation partition remains available. The 100% condition is primary.
Model size, pretraining data, and transforms differ, so this is a system-level
comparison rather than an isolated test of architecture or training objective.

## Primary held-out results
Mean ± sample SD across the three repeated splits:

| Model | Accuracy (%) | Balanced accuracy (%) | Macro-F1 (%) | Weighted-F1 (%) |
|---|---:|---:|---:|---:|
| majority | 19.35 ± 0.00 | 11.11 ± 0.00 | 3.60 ± 0.00 | 6.28 ± 0.00 |
| resnet18 | 81.11 ± 2.31 | 82.55 ± 2.43 | 81.67 ± 2.46 | 81.02 ± 2.37 |
| siglip2 | 92.43 ± 0.64 | 92.88 ± 0.54 | 92.47 ± 0.58 | 92.41 ± 0.66 |

The SigLIP 2 minus ResNet-18 mean macro-F1 difference is +10.79
percentage points. For preselected seed 42, a paired image-level percentile
bootstrap with 1,000 resamples gives a conditional 95% difference interval of
[+7.44, +13.36] percentage points. This is conditional on
one fitted pair and split and assumes independent test images; it does not
measure training, capture-session, or site uncertainty. The three repeated test
sets overlap, so their SD is descriptive split sensitivity, not an independent-run CI.

## Label-efficiency results
Full validation labels are used in all conditions. Percentages refer to the train
partition; no strict few-shot or zero-shot claim is made.

| Model | Training labels (%) | Macro-F1 (%) |
|---|---:|---:|
| resnet18 | 10 | 66.38 ± 2.06 |
| resnet18 | 25 | 73.64 ± 3.14 |
| resnet18 | 100 | 81.67 ± 2.46 |
| siglip2 | 10 | 86.65 ± 2.06 |
| siglip2 | 25 | 88.71 ± 0.92 |
| siglip2 | 100 | 92.47 ± 0.58 |

![Label efficiency](label_efficiency.png)

## Error analysis (preselected seed 42, all training labels)
The lowest per-class F1 for SigLIP 2 is Miscellaneous Trash
(79.73%). Confusion matrices report counts with row-normalized
color. The highest-confidence errors, when present, appear in error_examples.png;
classifier probabilities are uncalibrated. These examples describe observed failures
and do not establish their causes.

| Material | Precision (%) | Recall (%) | F1 (%) | Support |
|---|---:|---:|---:|---:|
| Miscellaneous Trash | 80.82 | 78.67 | 79.73 | 75 |
| Cardboard | 91.18 | 89.86 | 90.51 | 69 |
| Plastic | 94.53 | 87.68 | 90.98 | 138 |
| Paper | 88.75 | 94.67 | 91.61 | 75 |
| Textile Trash | 91.84 | 93.75 | 92.78 | 48 |
| Glass | 88.73 | 100.00 | 94.03 | 63 |
| Metal | 94.87 | 94.07 | 94.47 | 118 |
| Food Organics | 95.16 | 95.16 | 95.16 | 62 |
| Vegetation | 96.92 | 96.92 | 96.92 | 65 |

![Confusion matrices](confusion_matrices.png)

## Compute
Hardware: Tesla T4 (14.6 GiB device memory).
One CUDA device; batch size 32; float16 autocast for encoder inference.
Full feature extraction includes data loading, preprocessing and transfers, but excludes
checkpoint downloading/loading and warmup. Peak memory is PyTorch allocated memory,
not all driver allocations. Classifier fitting is on the CPU. Cached timing values
refer to the original extraction recorded in each cache's metadata.

| Encoder | Backbone parameters | Extraction (s) | Images/s | Peak allocated GPU GiB |
|---|---:|---:|---:|---:|
| resnet18 | 11,176,512 | 19.7 | 241.3 | 0.18 |
| siglip2 | 92,884,224 | 21.6 | 220.3 | 0.52 |

Elapsed notebook work after package setup: 178.9 s.
Package versions and the full environment lock are saved with the results.

## Limitations and interpretation
- Exact deduplication does not eliminate near-duplicates or scene correlations.
- No capture-group labels or independent landfill-site test set are available here.
- The pretrained WebLI dataset is not fully inspectable for benchmark overlap;
  contamination cannot be ruled out. ImageNet and WebLI pretraining differ substantially.
- The experiment tests frozen transfer. It does not establish optimal fine-tuned performance.
- Three overlapping image-level splits provide limited uncertainty assessment.
- Single-label material classification does not detect multiple objects, identify every
  material in an image, determine local recyclability, or detect unknown classes.
- Published RealWaste scores with other splits/protocols are background context only.

## Conclusion
Under this fixed evaluation protocol, SigLIP 2 has higher mean macro-F1 than
the frozen ResNet-18 baseline by 10.79 percentage points.
This measured outcome supports a scoped discussion of the selected model–dataset
application, with the generalization and novelty limitations above.

## References and source terms
1. Tschannen et al. (2025), SigLIP 2. https://arxiv.org/abs/2502.14786
2. SigLIP 2 image encoder and Apache-2.0 model card:
   https://huggingface.co/timm/vit_base_patch16_siglip_224.v2_webli
3. Single, Iranmanesh & Raad (2023), RealWaste dataset, UCI:
   https://doi.org/10.24432/C5SS4G
4. Single et al. (2023), RealWaste: A Novel Real-Life Data Set for Landfill Waste
   Classification Using Deep Learning. https://doi.org/10.3390/info14120633
5. ResNet-18 checkpoint: https://huggingface.co/timm/resnet18.a1_in1k
6. Funk et al. (2026), Evaluation of vision–language models for waste classification:
   Zero- and few-shot with a training-free tip-adapter. https://doi.org/10.1016/j.clwas.2026.100475

UCI lists CC BY 4.0 for RealWaste. The authors' GitHub README lists CC BY-NC-SA 4.0
(https://github.com/sam-single/realwaste). Preserve attribution and verify applicable
terms before redistributing the images; this project downloads them for an academic study.
